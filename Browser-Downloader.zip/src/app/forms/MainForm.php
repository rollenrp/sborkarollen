<?php
namespace app\forms;

use bundle\jurl\jURL;
use php\gui\UXWebEngine;
use action\Element;
use php\gui\framework\AbstractForm;
use php\gui\event\UXWindowEvent;
use php\gui\UXTab;
use php\time\Time;
use php\gui\event\UXEvent;
use php\gui\UXWebView;
use php\gui\event\UXMouseEvent;
use php\gui\event\UXKeyEvent;

class MainForm extends AbstractForm
{

    /**
     * @event show 
     **/
    function doShow(UXWindowEvent $event)
    {    
        $this->openTab('https://tssaltan.ru/1216.develnext-browser-webview-download-files/?from=dn-browser');
        $this->openTab('http://google.com/');
        
        jURL::requreVersion('1.0.2');
    }

    /**
     * @event tabs.close 
     **/
    function doTabsClose(UXEvent $event)
    {    
        if($this->tabs->tabs->count == 0){
            $this->openTab();
        }
    }

    /**
     * @event tabs.change 
     **/
    function doTabsChange(UXEvent $event)
    {    
        $browser = $this->getActiveBrowser();
        $this->browserUrl->text = $browser->location;
        $this->loadState->visible = $browser->state!='SUCCEEDED';
    }

    /**
     * @event forw.click 
     **/
    function doForwClick(UXMouseEvent $event)
    {    
        if($this->getActiveBrowser()->history->currentIndex == sizeof($this->getActiveBrowser()->history->getEntries())-1) return;
        $this->getActiveBrowser()->history->goForward();
    }

    /**
     * @event back.click 
     **/
    function doBackClick(UXMouseEvent $event)
    {    
        if($this->getActiveBrowser()->history->currentIndex == 0) return;
        $this->getActiveBrowser()->history->goBack();
    }

    /**
     * @event reload.click 
     **/
    function doReloadClick(UXMouseEvent $event)
    {    
        $doc = $this->getActiveBrowser()->reload();
    }

    /**
     * @event browserUrl.keyDown-Enter 
     **/
    function doBrowserUrlKeyDownEnter(UXKeyEvent $event)
    {    
        $this->getActiveBrowser()->load($this->browserUrl->text);
    }

    /**
     * @event newtab.click 
     **/
    function doNewtabClick(UXMouseEvent $event)
    {    
        $this->openTab();
        $this->tabs->selectLastTab();
    }

    /**
     * @event firebug.action 
     */
    function doFirebugAction(UXEvent $event = null)
    {    
        $this->getActiveBrowser()->executeScript("(function(F,i,r,e,b,u,g,L,I,T,E){if(F.getElementById(b))return;E=F[i+'NS']&&F.documentElement.namespaceURI;E=E?F[i+'NS'](E,'script'):F[i]('script');E[r]('id',b);E[r]('src',I+g+T);E[r](b,u);(F[e]('head')[0]||F[e]('body')[0]).appendChild(E);E=new Image;E[r]('src',I+L);})(document,'createElement','setAttribute','getElementsByTagName','FirebugLite','4','firebug-lite.js','releases/lite/latest/skin/xp/sprite.png','https://getfirebug.com/','#startOpened');");
    }

    /**
     * @event tabs.keyDown-Ctrl+U 
     */
    function doTabsKeyDownCtrlU(UXKeyEvent $event = null)
    {           
        $doc = $this->getActiveBrowser()->document;
        $xml = new \php\xml\XmlProcessor;
        
        $new = $this->openTab('');
        $new->loadContent($xml->format($doc), 'text/plain');
    }

    /**
     * Возвращает элемент браузера из активной вкладки
     **/
    public function getActiveBrowser(){
        $tab = $this->getActiveTab();
        return $tab->content->engine;
    }

    public function getActiveTab(){
        return $this->tabs->tabs[$this->tabs->selectedIndex];
    }
    
    /**
     * Создание новой вкладки браузера
     **/     
    public function openTab($url = 'http://google.com'){       
        $tab = new UXTab();
        $tab->text = $url;

        $browser = new UXWebView;

        $browser->engine->watchState(function($self, $old, $new) use ($browser, $tab){
            
            if($this->isActive($browser->id)){
                $this->browserUrl->text = $self->location;
                $this->loadState->visible = $new!='SUCCEEDED';
            }
            
            // Загрузчтк файлов
            if($old == 'RUNNING' and $new == 'CANCELLED'){
                $this->checkDownload($self->location);
            }
            
            $tab->text = substr( ((is_null($self->title))?$self->location:$self->title) ,0,15);
        });        

        
        $browser->engine->load($url);
        $tab->content = $browser; //*/
        
        $this->tabs->tabs[] = $tab;
        
        return $browser->engine;
    }

    /**
     * Проверяет, является ли переданный id браузера в активной вкладке
     **/
    public function isActive($elid){
        return $elid  ==  $this->getActiveTab()->content->id;
    }
}
