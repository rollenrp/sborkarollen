<?php
namespace app\forms;

use php\lib\str;
use bundle\jurl\jURL;
use php\gui\event\UXEvent;
use php\gui\framework\AbstractForm;
use php\gui\event\UXWindowEvent; 


class DownloadForm extends AbstractForm
{
    /**
     * @event showing 
     */
    function doShowing(UXWindowEvent $event = null)
    {        
        jURL::requreVersion('1.0.1');
    }

}
