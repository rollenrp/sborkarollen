<?php
namespace app\modules;

use bundle\jurl\jURL;
use php\gui\framework\AbstractModule;


class DownloadModule extends AbstractModule
{
    public function checkDownload($url){
        app()->getForm('DownloadForm')->fileUrl->text = $url; 
        $this->jdownloader->url = $url;
        $this->jdownloader->checkDownload(function(){
            app()->getForm('DownloadForm')->showAndWait();
        });       
        
             
    }
}