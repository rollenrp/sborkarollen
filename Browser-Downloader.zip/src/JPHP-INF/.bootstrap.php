<?php

// Generated.

use php\gui\framework\Application;



$app = new Application();
$app->launch();

